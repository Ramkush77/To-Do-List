let tasks = [];

// Load tasks from localStorage
if (localStorage.getItem("tasks")) {
  tasks = JSON.parse(localStorage.getItem("tasks"));
  displayTasks();
}

// Function to add a new task
function addTask() {
  const taskInput = document.getElementById("task-input");
  const taskText = taskInput.value.trim();

  if (taskText === "") return;

  const newTask = {
    id: Date.now(),
    text: taskText
  };

  tasks.push(newTask);
  localStorage.setItem("tasks", JSON.stringify(tasks));
  taskInput.value = "";
  displayTasks();
}

// Function to display tasks
function displayTasks(filter = "") {
  const taskList = document.getElementById("task-list");
  taskList.innerHTML = "";

  tasks
    .filter(task => task.text.toLowerCase().includes(filter.toLowerCase()))
    .forEach(task => {
      const li = document.createElement("li");
      li.setAttribute("data-id", task.id);
      li.innerHTML = `
        <span>${task.text}</span>
        <input type="text" class="edit-input" style="display: none;" />
        <div class="action-buttons">
          <button class="edit-btn" onclick="startEditTask(${task.id})">Edit</button>
          <button class="save-btn" style="display: none;" onclick="saveTask(${task.id})">Save</button>
          <button class="delete-btn" onclick="deleteTask(${task.id})">Delete</button>
        </div>
      `;
      taskList.appendChild(li);
    });
}

// Function to delete a task
function deleteTask(taskId) {
  tasks = tasks.filter(task => task.id !== taskId);
  localStorage.setItem("tasks", JSON.stringify(tasks));
  displayTasks();
}

// Function to start editing a task
function startEditTask(taskId) {
  const li = document.querySelector(`li[data-id="${taskId}"]`);
  const span = li.querySelector("span");
  const input = li.querySelector(".edit-input");
  const editBtn = li.querySelector(".edit-btn");
  const saveBtn = li.querySelector(".save-btn");

  input.value = span.textContent;
  span.style.display = "none";
  input.style.display = "block";
  editBtn.style.display = "none";
  saveBtn.style.display = "block";
}

// Function to save the edited task
function saveTask(taskId) {
  const li = document.querySelector(`li[data-id="${taskId}"]`);
  const span = li.querySelector("span");
  const input = li.querySelector(".edit-input");
  const editBtn = li.querySelector(".edit-btn");
  const saveBtn = li.querySelector(".save-btn");

  const newText = input.value.trim();
  if (newText === "") return;

  tasks = tasks.map(task => 
    task.id === taskId ? { ...task, text: newText } : task
  );

  localStorage.setItem("tasks", JSON.stringify(tasks));
  span.textContent = newText;
  span.style.display = "block";
  input.style.display = "none";
  editBtn.style.display = "block";
  saveBtn.style.display = "none";
}

// Function to search tasks
function searchTasks() {
  const searchInput = document.getElementById("search-input");
  displayTasks(searchInput.value);
}